---
layout: post
title: "Governor's Welcome"
author:
- sam
comments: true
share: true
---

Hello New Jersey District,

My main goals for this year are to have better district events, improve communication, and build K Families. Each of my goals is extremely important and it is club members such as ourselves that make Key Club possible. I hope to hear from you soon with any comments questions or concerns you may have. My email is [NJGovernorLevisay@gmail.com](mailto:njgovernorlevisay@gmail.com) and I would be more than happy to just chat about Key Club or send you my newsletter.

With this new year upon us the New Jersey District Board has been working fervently to keep the District up to date. From ELIMINATE week to RTCs we have been very busy making sure you are informed.

To this date I have personally accomplished the following:

- Obtained Governor files from the Immediate-Past Governor Ryan Clarkin
- Kept in contact with district board members in order to ensure all committees and clubs are in good contact
- Kept in very close contact with District Adminstrator Ms.McCann
- Sent out my Letter of Introduction to the New Jersey District Board of Trustees, Kiwanis Committee of Key Club, International President, and anyone who requested it
- Reviewed committee preference sheets and formed both the standing committees and special event committees for the 2014/2015 service year
- Modified all committee directives and emailed them to the appropriate recipients
- Sent out committee final reports to all chairs
- Modified all Officersí Training Manuals to be handed out to Lieutenant Governors at the April board meeting
- Signed up for the Governors-Administrators Training  Conference held in Indianapolis
- Created the agendas and prepared for the April Executive and District Board Meetings
- Kept in contact with the District Board, Kiwanis Committee, International Council and various Key Clubbers
- Submitted my Governor Monthly Report for March/April
- Attended the SLP reporting call for New Jersey to talk about New Jersey's progress with the ELIMINATE Project
- Sent out the current dues report and informed LTGs of non dues paid clubs
- Registered for ICON 2014!
- Contacted every LTG and Executive member atleast once
