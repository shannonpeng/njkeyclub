---
layout: post
title:  "What to Expect at Fall Rally"
author:
- daniel
comments: true
share: true
---

Are you ready to Get Animated with Service at Fall Rally 2014? What is Fall Rally? Fall Rally is the largest gathering of NJ Key Clubbers to motivate Key Clubbers to have a great rest of the service year. This year Fall Rally will be on October 12th at Six Flags Great Adventure in Jackson, New Jersey. In the wee hours of the morning you and your Key Club will travel to the amusement park to meet about 3,000 Key Clubbers from all across New Jersey! Get ready to see the NJ District Board dress up as your favorite animated characters ranging from Aang to Wanda! Get ready to learn all about what the New Jersey District is doing ranging from Eliminate updates, Advocacy information, dues, and different district events during the session!

Another highlight of the event will be the spirit stick competition! Every division will have to prove how ready they are for the service year as they cheer their heads off hoping to be the loudest division in the district! The winner will win the coveted spirit stick! The day does not have to end with this fun session! Clubs have the option to explore the park and go on the rides before the park officially opens! Your club will also have the option to stay for Fright Fest.
Although Fall Rally is on October 12th, Key Clubs should start preparing now! You should be sure to stress the importance of attending Fall Rally from the start of the school year and then talk to your current Lieutenant Governor or any District Board member about how many people your club will be taking to Fall Rally or if there is an issue or concern regarding transportation, etc. Fall Rally is great way to get to know people who share the same passion for service as you, meet the members of the New Jersey District Board, and have lots of fun!

**Early Registration:** $37.00

**Season Pass:** $6.00

**Late Registration:** $41.00
