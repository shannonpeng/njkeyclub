---
layout: post
title: "LTG Division 10 Says Hello!"
author:
- brooke
comments: true
share: false
toc: true
---

Hi everyone! My name is Brooke Willemstyn, the appointed lieutenant governor of division 10 of the great NJ District. This year, I'll try to stress communication from the district level to the club level, and keep all my presidents as informed as they can be.

# Attention Club Officers of Division 10!

I have officially called you out for this service year. Make your general members feel important. They are the essence of Key Club! I am responsible to flow information from the district level, to the club officer level, but I need to be certain you don't stop the flow there. Other members need to know what's going on in order to want to get involved.

# Attention Club Officers of the NJ District

None of you are lucky in sliding by with a lazy lieutenant governor. The board this year is absolutely fabulous, and they will be on top of everything you do, so don't let them down!

# What I Expect (Division 10 Specific)

I expect you forward my newsletters, flyers, and all informational or promotional files to your clubs. I require that everyone fills out the forms I send early, and at worst on time. If that means the secretary is on vacation in Guatemala for a month, either your club CMRF is in before she leaves, or another officer is filling out the club monthly report form for that month.

# What You Should Expect

You should expect change. You should be seeing some of the ideas your club has envisioned being realized on the district level. Expect me to communicate with you, and for Division 10 to have the best divisional projects in the district.

Thanks for reading this post, be professional, responsible, and lead this division 10 and our NJ District towards success this service year!
